x=5
y=84654845454842145454421
z=45.475654
p=5+2j

print(type(x))
print(type(y))
print(type(p))


a=1000*1000
print(a)

b=100000*10000
print(b)