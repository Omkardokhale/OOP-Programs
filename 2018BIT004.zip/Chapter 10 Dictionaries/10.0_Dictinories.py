#---------------------creat dic name is eng2sp-------------------------------------#
eng2sp = {}
eng2sp['one'] = 'uno'
eng2sp['to'] = 'dos'

print(eng2sp)

#-----------------------key-value pairs----------------------------------------------#

eng2sp = {'one': 'uno', 'two': 'dos', 'three': 'tres'}
print(type(eng2sp))
print(eng2sp)
print("two")
