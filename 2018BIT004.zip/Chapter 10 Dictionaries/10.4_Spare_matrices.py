matrix = {(0,3): 1, (2, 1): 2, (4, 3): 3}
matrix [0,3]
print(matrix)

#---------------------------------------------------

matrix.get((0,3), 0)
print(matrix)