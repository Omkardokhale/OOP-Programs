
a = {'one': 'A', 'two': 'B', 'three': 'C'}
print (a.keys())

print (a.values())

print (a.items())

