fruits = ["apple", "banana", "cherry"]

x = fruits.count("cherry")

print(x)