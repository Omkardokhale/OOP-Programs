x = 5
y = 10

temp = x
x = y
y = temp

print(x)
print(y)