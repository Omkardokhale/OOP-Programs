
def inBucket(t,low, high):
 count = 0
 for num in t:
  if low < num < high:
   count = count + 1
 return count

low = inBucket(0.0, 0.5)
high = inBucket(0.5, 1)

bucket1 = inBucket(0.0, 0.25)
bucket2 = inBucket(0.25, 0.5)
bucket3 = inBucket(0.5, 0.75)
bucket4 = inBucket(0.75, 1.0)

numBuckets=4
 
bucketWidth=1.0/numBuckets
for i in range(numBuckets):
      low=i*bucketWidth
      high=low+bucketWidth
      print (low,"to",high)
