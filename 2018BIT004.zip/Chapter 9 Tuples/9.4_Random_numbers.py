import random

for i in range(10):
    x=random.random()
    print(x)