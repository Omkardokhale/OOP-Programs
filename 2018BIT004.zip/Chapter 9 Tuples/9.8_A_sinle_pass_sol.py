import random
def randomList(n):
    s=[0]*n
    for i in range(n):
        s[i]=random.random()
    return s
List=[]
List=randomList(10)
print (List)

numBuckets = 8
buckets = [0] * numBuckets
for i in List:
 index = int(i * numBuckets)
buckets[index] = buckets[index] + 1
print(buckets)