a = ['one', 'two', 'three']
del a[1]
print(a)

#----------------------2nd ex-----------------------#

list = ['a', 'b', 'c', 'd', 'e', 'f']
del list[1:2]
print(list)

