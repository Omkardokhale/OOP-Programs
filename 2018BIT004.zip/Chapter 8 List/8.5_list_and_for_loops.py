a=range(20)
print(a)
 
for number in range(20):
    if number%2==0:
        print (number)

#-------------------------------------------
print("-----------------------------------")

c=["banana", "apple", "quince"]

a=["I like to eat"]
print(a+c)

print("-----------------------------------")


    