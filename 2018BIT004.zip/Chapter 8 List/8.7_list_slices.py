list=['a','b','c','d','e','f','g','h']
print(list[1:3])
print(list[:4])
print(list[3:])
print(list[:])