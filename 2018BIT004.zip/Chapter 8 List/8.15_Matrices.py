matrix = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
a=matrix[1]
b=matrix[1][1]
c=matrix[:2][0]
d=matrix[:5][1]
e=matrix[:8][2]
print(a)
print(b)
print(c)
print(d)
print(e)
