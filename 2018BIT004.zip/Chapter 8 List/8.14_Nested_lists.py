list=["Omkar",2021,2.3,[1,2]]
elt=list[3]
print(elt)


