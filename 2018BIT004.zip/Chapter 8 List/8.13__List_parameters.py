def head(list):
    return list[0]
a="Here how it is used:" 
num=[1,2,3]
print(head(num))

#------------------2nd ex-------------------------#

def deleteHead(list):
    del list[0]
a="Here’s how deleteHead is used:"
num=[1,2,3]
deleteHead(num)
print(num)
