a="Omkar"
b="Omkar"

print(id(a))
print(id(b))

#-----------------------2nd ex--------------------------#

c=[1,2,3]
d=[1,2,3]

print(id(c))
print(id(d))