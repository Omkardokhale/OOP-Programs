print("---------------------------------------------------------------")

horsemen = ["war", "famine", "pestilence", "death"]
a=len(horsemen)
i=0
while i<a:
    print(horsemen[i])
    i=i+1

print("----------------------------------------------------------------")



