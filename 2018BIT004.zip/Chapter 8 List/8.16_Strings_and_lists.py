#-------------------String splite--------------------#


txt = "welcome to the jungle"
x = txt.split()
print(x)

#---------------------- join string----------------#

list = ['The', 'rain', 'in', 'Spain...']
a="".join(list)
print(a)