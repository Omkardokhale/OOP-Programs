
horsemen = ["war", "famine", "pestilence", "death"]

i = 0
while i < 3:
 i = i + 1
 print (horsemen[i])
