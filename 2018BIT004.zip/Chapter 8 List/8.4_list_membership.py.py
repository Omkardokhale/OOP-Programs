horsemen = ["war", "famine", "pestilence", "death"]

print('pestilence' in horsemen)
print('Omkar' in horsemen)
#-------------------------------------------------------------

a=['Omkar','Ram','Rahul','Vaibhav']
print('Omkar' in a)
print('Suraj' in a)
