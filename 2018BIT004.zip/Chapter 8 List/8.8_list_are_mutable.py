name=["Omkar","Ram","Suraj","Ravi","Raj"]
name[0]="Om"
name[1]="kar"
name[4]="Vaibhav"

print(name)

#-----------------------2nd ex--------------------------------#

a=['a','b','c','d','e','f','g']
a[0:2]=['x','y','z']
a[:3]=['p']
a[4:]=['a','b','c']

print(a)

