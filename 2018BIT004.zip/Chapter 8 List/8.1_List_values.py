
a=[10,20,30,40]
b=["spam", "bungee", "swallow"]
print (a)

#----------------------------------------------------------------------
vocabulary = ["ameliorate", "castigate", "defenestrate"]
numbers = [17, 123]
empty = []
print (vocabulary, numbers, empty)

#----------------------------------------------------------------------

